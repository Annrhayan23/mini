const jsonCategories = [
  {
    "name": "Jersey"
  },
  {
    "name": "Balon"
  },
  {
    "name": "Calzado"
  },
  {
    "name": "Short"
  },
];

module.exports= jsonCategories;