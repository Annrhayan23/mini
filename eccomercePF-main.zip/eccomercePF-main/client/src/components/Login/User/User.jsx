import React from "react";
import Profile from "./Profile";

function User() {
  return (
    <div className="container">
      <Profile />
    </div>
  );
}

export default User;
