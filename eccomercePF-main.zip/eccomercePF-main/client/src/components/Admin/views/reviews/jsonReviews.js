const data = [
  {
    user: "Liss",
    stars: 4,
    product_name: "Jersey",
    comment: "Este es un comentario",
  },
  {
    user: "Exe",
    stars: 3,
    product_name: "Jersey",
    comment: "Este es un comentario 1",
  },
];
export default data;
