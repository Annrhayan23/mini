const AdminHeader = () => {
  return <div className="header">Header</div>;
};
export default AdminHeader;
