const AdminFooter = () => {
  return <div>Footer</div>;
};
export default AdminFooter;
