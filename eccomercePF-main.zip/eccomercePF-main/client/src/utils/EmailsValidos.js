export const listEmails = [
  "spezialichristian@gmail.com",
  "spezialichristian@hotmail.com",
  "lnlindao@gmail.com",
  "edye.1230@gmail.com",
  "menas7527@gmail.com",
  "ivokoby@gmail.com",
  "gregorioescobara28@gmail.com",
  "exequielcostabel@gmail.com",
];
